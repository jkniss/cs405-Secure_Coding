// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
   Uncomment this test to see a failure in the test explorer
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());

    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsVectorMaxSizeValue) 
{

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // is vector size greater than or equal to 0?
    EXPECT_GE(collection->max_size(), 0);

    add_entries(1);

    // is vector size greater than or equal to 1?
    EXPECT_GE(collection->max_size(), 1);

    add_entries(5);

    // is vector size greater than or equal to 5?
    EXPECT_GE(collection->max_size(), 5);

    add_entries(10);

    // is vector size greater than or equal to 10?
    EXPECT_GE(collection->max_size(), 10);
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsVectorCapacitySizeBigger) 
{

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // is capacity greater than or equal to collection size (0)?
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(1);

    // is capacity greater than or equal to collection size (1)?
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(5);

    // is capacity greater than or equal to collection size (6)?
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(10);

    // is capactiy greater than or equal to collection size (16)?
    EXPECT_GE(collection->capacity(), collection->size());


}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, IsVectorResizeBigger) 
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    // is vector size equal to 5?
    ASSERT_TRUE(collection->size(), 5);

    // does vector resize to -1 throw an error?
    //ASSERT_THROW(collection->resize(-1), std::exception);

    //does vector resize to 12 throw an error?
    ASSERT_NO_THROW(collection->resize(12));

    // is new vector size equal to 12?
    ASSERT_EQ(collection->size(), 12);

}


// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, IsVectorResizeSmaller)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(10);

    // is vector size equal to 10?
    EXPECT_TRUE(collection->size(), 10);

    // does vector resize throw an error?
    ASSERT_NO_THROW(collection->resize(5));

    // is new vector size equal to 5?
    ASSERT_EQ(collection->size(), 5);

}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, IsVectorResizeZero)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(417);

    // is vector size equal to 417?
    EXPECT_EQ(collection->size(), 417);

    // does vector resize throw an error?
    ASSERT_NO_THROW(collection->resize(0));

    // is new vector size equal to 0?
    ASSERT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, IsVectorCleared)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(250);

    // is vector size equal to 250?
    EXPECT_EQ(collection->size(), 250);

    // does vector clear throw an error?
    ASSERT_NO_THROW(collection->clear());

    // is new vector size equal to 0?
    ASSERT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, IsVectorErase)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(250);

    // is vector size equal to 250?
    EXPECT_EQ(collection->size(), 250);


    // does vector erase throw an error?
    ASSERT_NO_THROW(collection->erase(collection->begin(), collection->end()));

    // is vector size equl to 0 after erase?
    ASSERT_EQ(collection->size(), 0);

}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, IsVectorReserveIncrease)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(25);

    // is vector size equal to 25?
    EXPECT_EQ(collection->size(), 25);

    // does vector reserve throw an error?
    ASSERT_NO_THROW(collection->reserve(100));

    // is vector capactity equal to 100 after reserve?
    EXPECT_EQ(collection->capacity(), 100);

    // is vector size still equal to 25?
    EXPECT_EQ(collection->size(), 25);

}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, IsVectorOutOfBounds)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(25);

    // is vector size equal to 25?
    EXPECT_EQ(collection->size(), 25);

    // does vector throw an error when calling index out of bounds?
    ASSERT_THROW(collection->at(30), std::out_of_range);

}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// TODO: Create unit test that checks if an exception is thrown when vector is resized
// Note: This test is negative
TEST_F(CollectionTest, IsVectorResizeTooLarge)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(25);

    // is vector size equal to 25?
    EXPECT_EQ(collection->size(), 25);

    // does vector throw a length_error if resized above max_size
    ASSERT_THROW(collection->resize(1073741824), std::length_error);

}

// TODO: Create unit test that checks if capacity is reduced to fit its size 
// Note: This test is positive
TEST_F(CollectionTest, IsVectorContainerSmaller)
{
    // is collection empty?
    ASSERT_TRUE(collection->empty());

    add_entries(25);

    // is container size equal to 25?
    EXPECT_EQ(collection->size(), 25);

    // is an error thrown when collection capacity is set to 35
    ASSERT_NO_THROW(collection->reserve(35));

    // is collection capacity equal to 35?
    EXPECT_EQ(collection->capacity(), 35);

    // is an error thrown when collection capacity is set to collection size?
    ASSERT_NO_THROW(collection->shrink_to_fit());

    // is collection capacity equal to collection size?
    ASSERT_EQ(collection->capacity(), collection->size());

}